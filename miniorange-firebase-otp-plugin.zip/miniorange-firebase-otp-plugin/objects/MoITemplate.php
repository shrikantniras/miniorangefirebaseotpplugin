<?php

namespace MoOTP\Objects;

interface MoITemplate
{
    
    public static function instance();
    
}