<?php

namespace MoOTP\Objects;

interface IFormHandler
{
    public function handle_mofirebase_form();
    public function handle_mofirebase_form_options();
    
    
}